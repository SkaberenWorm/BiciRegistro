<?php

setlocale(LC_ALL, 'es_CL');
echo (date("d/m/Y H:i:s "));
?>
