<?php

namespace BiciRegistro\Http\Controllers;

use Illuminate\Http\Request;

class ImageController extends Controller
{
    //
}
